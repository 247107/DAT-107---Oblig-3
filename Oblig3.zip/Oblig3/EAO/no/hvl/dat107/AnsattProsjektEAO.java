package no.hvl.dat107;

import javax.persistence.EntityManagerFactory;
import javax.persistence.*;

public class AnsattProsjektEAO {
	private EntityManagerFactory emf;

	public AnsattProsjektEAO() {
		//emf = Persistence.createEntityManagerFactory("oblig3");
	}


}