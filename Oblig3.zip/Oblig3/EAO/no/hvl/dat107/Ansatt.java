package no.hvl.dat107;

import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Table(name = "Ansatt", schema = "Oblig3")
public class Ansatt {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int ansatt_id;
	
	private String brukernavn;
	private String fornavn;
	private String etternavn;
	private LocalDate ansettelsesDato;
	private String stilling;
	private int maanedslonn;
	private String avdeling;
	
	
	public Ansatt(String brukernavn, String fornavn, String etternavn, LocalDate ansettelsesDato, String stilling,
	int maanedslonn, String avdeling) {
	this.brukernavn = brukernavn;
	this.fornavn = fornavn;
	this.etternavn = etternavn;
	this.ansettelsesDato = ansettelsesDato;
	this.stilling = stilling;
	this.maanedslonn = maanedslonn;
	this.avdeling = avdeling;
	}


	public Ansatt() {
		// TODO Auto-generated constructor stub
	}


	public int getAnsatt_id() {
		return ansatt_id;
	}


	public void setAnsatt_id(int ansatt_id) {
		this.ansatt_id = ansatt_id;
	}


	public String getBrukernavn() {
		return brukernavn;
	}


	public void setBrukernavn(String brukernavn) {
		this.brukernavn = brukernavn;
	}


	public String getFornavn() {
		return fornavn;
	}


	public void setFornavn(String fornavn) {
		this.fornavn = fornavn;
	}


	public String getEtternavn() {
		return etternavn;
	}


	public void setEtternavn(String etternavn) {
		this.etternavn = etternavn;
	}


	public LocalDate getAnsettelsesDato() {
		return ansettelsesDato;
	}


	public void setAnsettelsesDato(LocalDate ansettelsesDato) {
		this.ansettelsesDato = ansettelsesDato;
	}


	public String getStilling() {
		return stilling;
	}


	public void setStilling(String stilling) {
		this.stilling = stilling;
	}


	public int getMaanedslonn() {
		return maanedslonn;
	}


	public void setMaanedslonn(int maanedslonn) {
		this.maanedslonn = maanedslonn;
	}


	public String getAvdeling() {
		return avdeling;
	}


	public void setAvdeling(String avdeling) {
		this.avdeling = avdeling;
	}


	@Override
	public String toString() {
		return "Ansatt [ansatt_id=" + ansatt_id + ", brukernavn=" + brukernavn + ", fornavn=" + fornavn + ", etternavn="
				+ etternavn + ", ansettelsesDato=" + ansettelsesDato + ", stilling=" + stilling + ", maanedslonn="
				+ maanedslonn + ", avdeling=" + avdeling + "]";
	}
	
	
	
	}	


